package com.example.user.json.controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.example.user.json.R;
import com.example.user.json.controller.httpTask.UserTask;
import com.example.user.json.model.entities.User;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayAdapter<User> userAdapter;
        ArrayList<User> contactList = new ArrayList<>();
        UserTask userTask = new UserTask();
        userTask.execute();
    }
}
