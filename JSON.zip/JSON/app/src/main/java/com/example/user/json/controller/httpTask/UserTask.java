package com.example.user.json.controller.httpTask;

import android.os.AsyncTask;


import com.example.user.json.model.api.JsonPlaceholderApi;
import com.example.user.json.model.entities.User;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;


public class UserTask extends AsyncTask<Void, Void, Void> {
    @Override
    protected Void doInBackground(Void... voids) {
        JsonPlaceholderApi api = new JsonPlaceholderApi("https://jsonplaceholder.typicode.com/users");
        try {
            ArrayList<User> user = api.getUserArray(1);



        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
